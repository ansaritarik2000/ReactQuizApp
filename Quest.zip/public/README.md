Hi there,
This is a basic react quiz app in which I used redux to dispatch the states required and reactJS to develop the UI of the webapp
I'll be focussing on to make this mobile responsive.
To use this you can fork this repo or even download the code

1. npm install to install the dependencies
2. npm start will do the work then localhost:3000 to be precise.

Thank you for visiting!!
