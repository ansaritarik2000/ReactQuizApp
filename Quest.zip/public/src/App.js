import React, { useEffect } from "react";
import "./App.css";
import { useSelector, useDispatch } from "react-redux";
import { fetchQuestions } from "./redux/action/questionAction"

import End from "./components/End";
import Question from "./components/Questions";
import Start from "./components/Start";

let interval;

const App = () => {
  const dispatch = useDispatch();
  const { step, answers } = useSelector((state) => state?.quizReducer);
  const { questions } = useSelector((state) => state?.questionReducer);

  useEffect(() => {
    dispatch(fetchQuestions());
  }, [dispatch]);

  useEffect(() => {
    if (step === 3) {
      clearInterval(interval);
    }
  }, [step]);

  return (
    <div className="App">
      {step === 1 && <Start />}
      {step === 2 && <Question questions={questions} />}
      {step === 3 && <End questions={questions} />}
    </div>
  );
};

export default App;
