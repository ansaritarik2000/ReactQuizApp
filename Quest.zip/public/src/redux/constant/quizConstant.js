export const QUIZ_START = "QUIZ_START"
export const QUIZ_RESET = "QUIZ_RESET"
export const QUIZ_NEXT = "QUIZ_NEXT"
export const QUIZ_PREV = 'QUIZ_PREV'
export const QUIZ_SUBMIT = 'QUIZ_SUBMIT'
export const QUIZ_TIMEOUT = 'QUIZ_TIMEOUT'