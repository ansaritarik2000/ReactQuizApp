import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import logger from "redux-logger";

import storage from "redux-persist/lib/storage";
import { persistReducer } from "redux-persist";

import quizReducer from "./quizReducer";
import questionReducer from "./questionReducer";

const rootPersistConfig = {
  key: "root",
  storage: storage,
  whitelist: ["quizReducer", "questionReducer"],
};

const rootReducer = combineReducers({
  quizReducer,
  questionReducer,
});

const persistedReducer = persistReducer(rootPersistConfig, rootReducer);

let middleware = [];
if (process.env.NODE_ENV === "development") {
  middleware = [...middleware, thunk, logger];
} else {
  middleware = [...middleware, thunk];
}

export const store = createStore(persistedReducer, {}, applyMiddleware(...middleware));
