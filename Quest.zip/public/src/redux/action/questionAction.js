import {
  FETCH_QUESTIONS_REQUEST,
  FETCH_QUESTIONS_SUCCESS,
  FETCH_QUESTIONS_FAILURE,
} from '../constant/questionConstant';
import shuffle from 'lodash/shuffle';


export const fetchQuestionsRequest = () => ({
  type: FETCH_QUESTIONS_REQUEST,
});




const shuffleAnswers = (correctAnswer, incorrectAnswers) => {
  const allAnswers = [...incorrectAnswers, correctAnswer];
  return shuffle(allAnswers);
};

export const fetchQuestionsSuccess = (questions) => {
  // Shuffle the answer options for each question
  const shuffledQuestions = questions.map((question) => {
    const { incorrect_answers, correct_answer } = question;
    const shuffledAnswers = shuffleAnswers(correct_answer, incorrect_answers);

    return {
      ...question,
      incorrect_answers: shuffledAnswers.slice(0, -1), 
      correct_answer: shuffledAnswers[shuffledAnswers.length - 1], 
    };
  });

  return {
    type: FETCH_QUESTIONS_SUCCESS,
    payload: shuffledQuestions,
  };
};

export const fetchQuestionsFailure = (error) => ({
  type: FETCH_QUESTIONS_FAILURE,
  payload: error,
});

export const fetchQuestions = () => {
  return async (dispatch) => {
    dispatch(fetchQuestionsRequest());
    try {
      const response = await fetch('https://opentdb.com/api.php?amount=10&type=multiple');
      const data = await response.json();
      dispatch(fetchQuestionsSuccess(data.results));
    } catch (error) {
      dispatch(fetchQuestionsFailure(error.message));
    }
  };
};
