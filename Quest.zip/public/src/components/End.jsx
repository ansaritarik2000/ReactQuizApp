import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { resetQuiz } from "../redux/action/quizAction";
import { formatTime } from "../utils";
import Modal from "./Modal";
import Trophy from "../assets/images/trophy.png";

const End = ({ questions }) => {
  const dispatch = useDispatch();
  const { answers, time } = useSelector((state) => state.quizReducer);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [modal, setModal] = useState(false);

  useEffect(() => {
    let correct = 0;
    answers.forEach((result, index) => {
      if (result.a === questions[index]?.correct_answer) {
        correct++;
      }
    });
    setCorrectAnswers(correct);
  }, [answers, questions]);

  const handleReset = () => {
    dispatch(resetQuiz());
  };

  return (
    <div className="endBox">
      <img src={Trophy} className="trophy" alt="" srcSet="" />
      <h3>Your results</h3>
      <p>
        {correctAnswers} of {questions.length}
      </p>
      <p>
        <strong>
          {Math.floor((correctAnswers / questions.length) * 100)}%
        </strong>
      </p>

      <section>
        <button className="button" onClick={() => setModal(true)}>
          Check your answers
        </button>
        <button
          className="button"
          style={{ marginLeft: "20px" }}
          onClick={handleReset}
        >
          Try again
        </button>
      </section>
      <Modal show={modal}>
        <section className="modalBody">
          <header>
            <p className="">Your Answers</p>
            <p
              style={{
                cursor: "pointer",
              }}
              onClick={() => setModal(false)}
            >
              X
            </p>
          </header>
          <section className="content">
            <ul>
              {answers.map((result, i) => (
                <li key={i} className="mb-6">
                  <p>
                    <strong>{questions[i]?.question}</strong>
                  </p>
                  <p
                    className={
                      result.a === questions[i]?.correct_answer
                        ? "bg-success"
                        : "bg-danger"
                    }
                  >
                    Your answer: {result.a}
                  </p>
                  {result.a !== questions[i]?.correct_answer && (
                    <p className="bg-warning">
                      Correct answer: {questions[i]?.correct_answer}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </section>
        </section>
      </Modal>
    </div>
  );
};

export default End;
