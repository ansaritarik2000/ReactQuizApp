import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  nextQuiz,
  prevQuiz,
  submitQuiz,
  startQuiz,
} from "../redux/action/quizAction";

const Question = () => {
  const dispatch = useDispatch();
  const { activeQuestion, answers, step } = useSelector(
    (state) => state?.quizReducer
  );
  const { questions } = useSelector((state) => state?.questionReducer);
  const [data, setData] = useState(null);
  const [selected, setSelected] = useState("");
  const [error, setError] = useState("");
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState("");

  const fetchData = async () => {
    try {
      if (!questions || questions.length === 0) {
        // Fetch questions only if not available
        dispatch(startQuiz()); // Assuming you have a startQuiz action
      }

      setData(questions[activeQuestion]);
    } catch (error) {
      console.error("Error fetching quiz data:", error);
    }
  };

  // Reset selected state when moving to a new question
  useEffect(() => {
    setSelected("");
  }, [activeQuestion]);

  useEffect(() => {
    fetchData();
    // Reset feedback when moving to the next question
    setShowFeedback(false);
    setFeedback("");
  }, [activeQuestion, step, dispatch, questions]);

  const radiosWrapper = useRef();

  useEffect(() => {
    if (data) {
      if (answers[activeQuestion] != undefined) {
        setSelected(answers[activeQuestion].a);
      }
    }
  }, [data, activeQuestion, answers]);

  const changeHandler = (e) => {
    setSelected(e.target.value);
    if (error) {
      setError("");
    }
    // Hide feedback when changing the answer
    setShowFeedback(false);
    setFeedback("");
  };

  const handlePrev = () => {
    setError("");
    dispatch(prevQuiz());
    // Hide feedback when moving to the previous question
    setShowFeedback(false);
    setFeedback("");
  };

  const handleNext = () => {
    if (selected === "") {
      return setError("Please select one option!");
    }

    // Create an array with the selected answer
    const answer = {
      q: data.question,
      a: selected,
    };

    dispatch(nextQuiz({ answers: [...answers, answer] }));
    setSelected("");

    // Show feedback when moving to the next question
    setShowFeedback(true);
  };

  const handleSubmit = () => {
    if (selected === "") {
      return setError("Please select one option!");
    }

    // Check if the answer is correct and set feedback message
    if (selected === data?.correct_answer) {
      setFeedback("Correct!");
    } else {
      setFeedback(`Incorrect! The correct answer is ${data?.correct_answer}.`);
    }

    // Show feedback when moving to the next question
    setShowFeedback(true);

    // Clear the error when the user submits a valid answer
    setError("");
  };

  const handleQuizSubmit = () => {
    if (selected === "") {
      return setError("Please select one option!");
    }
    dispatch(
      submitQuiz({
        answers: [
          ...answers,
          (answers[activeQuestion] = {
            q: data.question,
            a: selected,
          }),
        ],
      })
    );
  };

  const isLastQuestion = activeQuestion === questions.length - 1;
  console.log(isLastQuestion, "ye h");

  return (
    <div className="questionBox">
      <section className="questionHead">
        <h3>
          Question {activeQuestion + 1} / {questions.length}
        </h3>
      </section>
      <section className="middleBox">
        {data && (
          <div className="question">
            <p>{data?.question}</p>
            {error && <div className="error">{error}</div>}
          </div>
        )}
        <div className="option" ref={radiosWrapper}>
          {data?.incorrect_answers.map((choice, i) => (
            <label
              className={`${choice === selected ? `selected` : `text`}`}
              key={i}
            >
              <input
                type="radio"
                name="answer"
                value={choice}
                onChange={changeHandler}
                checked={choice === selected}
                disabled={showFeedback} // Disable radio buttons when feedback is shown
              />
              {choice}
            </label>
          ))}
          <label
            className={`${
              data?.correct_answer === selected ? `selected` : `text`
            }`}
          >
            <input
              type="radio"
              name="answer"
              value={data?.correct_answer}
              onChange={changeHandler}
              checked={data?.correct_answer === selected}
              disabled={showFeedback} 
            />
            {data?.correct_answer}
          </label>
        </div>
      </section>
      <section className="questionBottom">
        {showFeedback ? (
          <div className="feedback">
            <p
              className={
                selected === data?.correct_answer ? "correct" : "incorrect"
              }
            >
              {feedback}
            </p>
            
            {activeQuestion + 1 >= questions.length ? (
              <button className="button nextBtn" onClick={handleQuizSubmit}>
                Submit Quiz
              </button>
            ) : (
              <button className="button nextBtn" onClick={handleNext}>
                Next
              </button>
            )}
          </div>
        ) : (
          <button className="button nextBtn" onClick={handleSubmit}>
            Submit Answer
          </button>
        )}
        {activeQuestion <= 0 ? null : (
          <button className="button" onClick={handlePrev}>
            Prev
          </button>
        )}
        
      </section>
    </div>
  );
};

export default Question;
